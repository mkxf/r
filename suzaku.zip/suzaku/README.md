#suzaku

#架构说明
1.spring-mvc、spring、MyBatis

##目录结构简介
 * Spring Bean配置文件：src\main\resources\bean
 * MyBatis mapper文件：src\main\resources\db\mybatis
 * Freemaker模板文件：src\main\webapp\WEB-INF\views\ftls
 * 表结构及初始化脚本：src\main\resources\db\sql
 * Spring主配置文件：src\main\resources\applicationContext.xml
 * logback配置文件：src\main\resources\logback.xml
 * Spring MVC配置：src\main\resources\bean\spring-servlet.xml
 * Spring DAO配置：src\main\resources\bean\spring-dao.xml
 * Spring 数据源配置：src\main\resources\bean\spring-datasouce.xml


## Maven 命令使用简介

* 初始化Eclipse环境
  mvn eclipse:eclipse
* 清理Eclipse环境
  mvn eclipse:clean
* 清理
  mvn clean
* 运行
  mvn tomcat:run
* 运行(忽略单元测试)
  mvn tomcat:run -Dmaven.test.skip=true
* 打包运行
  mvn package tomcat:run -Dmaven.test.skip=true
* 清理并打包
  mvn clean package
  (注意：在eclipse中执行maven命令时取去掉命令中"mvn")
* 生产环境打包
  mvn clean package -P=prod -Dmaven.test.skip=true

## Resources
 * R1.http://www.mybatis.org/spring/
 * R2.http://git.oschina.net/free/Mybatis_PageHelper/blob/master/wikis/HowToUse.markdown
 * R3.http://sui.taobao.org/sui/docs/index.html
 * R4.http://www.bootcss.com/p/underscore/#template
 * R5.http://git.oschina.net/free/Mybatis_PageHelper/blob/master/wikis/UseOrderBy.md
 * R6.http://www.mybatis.org/mybatis-3/zh/dynamic-sql.html
 * R7.http://h2database.com/html/grammar.html
 * R8.http://docs.spring.io/spring/docs/4.3.x/spring-framework-reference/htmlsingle/
 * R9.https://www.owasp.org/index.php/Category:OWASP_AntiSamy_Project
 * R10.https://code.google.com/archive/p/owaspantisamy/downloads
 * R11.http://velocity.apache.org/tools/devel/apidocs/index.html
 * R12.http://outofmemory.cn/code-snippet/3700/spring-bean-property-inject

## Q&A
 * Q1.415 Unsupported Media Type
 * A1.ajax方法设置contentType : 'application/json'
 * Q2.how to get list of Databases “Schema” names of MySql using java JDBC
 * A2.http://stackoverflow.com/questions/5679259/how-to-get-list-of-databases-schema-names-of-mysql-using-java-jdbc
    or http://forums.mysql.com/read.php?39,518798,518816#msg-518816
 * Q3.How to change servlet request body in java filter?
 * A3.http://stackoverflow.com/questions/34155480/how-to-change-servlet-request-body-in-java-filter
 * Q4.what is the simplest way to convert a java string from all caps words separated
 * A4.http://stackoverflow.com/questions/1143951/what-is-the-simplest-way-to-convert-a-java-string-from-all-caps-words-separated
 * Q5.能否将spring－dao中的动态dao配置省略改为注解方式实现？
 * A6.http://blog.csdn.net/lemonyfei/article/details/8925351
