package com.wj.suzaku;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.json.JSONObject;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

public class MySqlDB {

	public static void main(String[] args) {
		try {
			Driver driver = (Driver) Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url="jdbc:mysql://localhost:3306/mysql";
			String username="root";
			String password = "sa";
			DataSource dataSource = new SimpleDriverDataSource(driver, url, username, password );
			Connection conn = DataSourceUtils.getConnection(dataSource);
			System.out.println(JSONObject.valueToString(conn));
			DatabaseMetaData metadata = conn.getMetaData();
			System.out.println(JSONObject.valueToString(metadata));
			ResultSet rs = metadata.getCatalogs();
			System.out.println(JSONObject.valueToString(rs));
			List<String> schemas = new ArrayList<String>();
			while (rs.next()) {
				schemas.add(rs.getString(1));
			}
			System.out.println(JSONObject.valueToString(schemas));
	
		} catch (CannotGetJdbcConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
