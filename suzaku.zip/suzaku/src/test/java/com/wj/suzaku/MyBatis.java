package com.wj.suzaku;

import java.sql.Driver;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.json.JSONObject;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.wj.suzaku.core.SqlMapper;

public class MyBatis {
	public static void main(String[] args) {
		try {
//			Driver driver = (Driver) Class.forName("org.h2.Driver").newInstance();
//			String url="jdbc:h2:~/h2/information_schema";
//			String username="sa";
//			String password = "";
			
			Driver driver = (Driver) Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url="jdbc:mysql://localhost:3306/information_schema?useUnicode=true&characterEncoding=utf8";
			String username="root";
			String password = "sa";
			
//			Driver driver = (Driver) Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
//			String url="jdbc:oracle:thin:@192.168.1.115:1521:orcl";
//			String username="SJBANK";
//			String password = "SJBANK";
			
			DataSource dataSource = new SimpleDriverDataSource(driver, url, username, password );
			
			SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
			factoryBean.setDataSource(dataSource);
			SqlSessionFactory sqlSessionFactory = factoryBean.getObject();
			SqlSession sqlSession = sqlSessionFactory.openSession();
			//创建sqlMapper
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			String statement = "select SCHEMA_NAME from information_schema.schemata";//MySQL|H2
//			String statement = "select username AS SCHEMA_NAME from dba_users";//ORACLE
			List<Map<String,Object>> rs = sqlMapper.selectList(statement);
			System.out.println(JSONObject.valueToString(rs));
			
//			statement = "SELECT T.TABLE_NAME, T.COMMENTS as table_desc FROM ALL_TAB_COMMENTS T WHERE T.TABLE_TYPE = 'TABLE' AND T.OWNER = 'SJBANK'";//ORACLE
			statement = "SELECT SCHEMA_NAME as schema,TABLE_NAME, TABLE_COMMENT as table_desc FROM TABLES WHERE TABLE_SCHEMA = 'TEST'";//MySQL
			rs = sqlMapper.selectList(statement);
			System.out.println(JSONObject.valueToString(rs));
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
