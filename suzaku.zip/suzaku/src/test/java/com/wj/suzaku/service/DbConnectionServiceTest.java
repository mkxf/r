package com.wj.suzaku.service;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.json.JSONObject;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wj.suzaku.AppCtxSupport;
import com.wj.suzaku.model.DbConnection;

public class DbConnectionServiceTest extends AppCtxSupport {
	
	private static final Logger log = LoggerFactory.getLogger(DbConnectionServiceTest.class);
	
	@Autowired
	DbConnectionService dbConnectionService;
	String id;

	@Test
	public void testCreate() {
		JSONObject json = new JSONObject("{\"name\":\"orcl_115\",\"type\":\"ORACLE\",\"host\":\"192.168.1.115\",\"username\":\"SJBANK\",\"password\":\"SJBANK\",\"schema\":\"SJBANK\"}");
		DbConnection obj = new DbConnection();
		try {
			BeanUtils.populate(obj, json.toMap());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		int rs = dbConnectionService.create(obj);
		id = obj.getId();
		log.info("name:{} saved",obj.getName());
		log.info(JSONObject.valueToString(rs));
		assertTrue(rs>0);
		
		/*dbConnectionDao.delete(id);
		log.info("name:{} deleted",obj.getName());*/
	}

}
