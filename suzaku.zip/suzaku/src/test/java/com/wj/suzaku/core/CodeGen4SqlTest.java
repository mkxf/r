package com.wj.suzaku.core;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CodeGen4SqlTest {
	
	private static Logger logger = LoggerFactory.getLogger(CodeGen4SqlTest.class);

	@Test
	public void testGenerate() {
		String filename = new CodeGen4Sql().getClass().getClassLoader().getResource(".").getPath() + "abc.xlsx";
		List<String> sqls = CodeGen4Sql.generate(filename,true,null,null);
		logger.debug("sqls:\n{}",sqls);
		assertNotNull(sqls);
		
		sqls = CodeGen4Sql.generate(filename, false,"t_user","name,sex,age,remark".split(","));
		logger.debug("sqls:\n{}",sqls);
		assertNotNull(sqls);
	}

}
