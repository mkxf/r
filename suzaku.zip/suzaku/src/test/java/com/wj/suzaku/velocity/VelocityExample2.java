package com.wj.suzaku.velocity;

import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.apache.velocity.tools.generic.DateTool;
import org.apache.velocity.tools.generic.DisplayTool;
import org.apache.velocity.tools.generic.EscapeTool;
import org.mybatis.spring.SqlSessionFactoryBean;

import com.google.common.base.CaseFormat;
import com.wj.suzaku.core.DataSourceFactory;
import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.service.MetadataService;
import com.wj.suzaku.core.service.impl.OracleMetadataServiceImpl;

public class VelocityExample2 {

	public static void main(String[] args) throws Exception {
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());

		ve.init();

		Template t = ve.getTemplate("model.vm");
		VelocityContext ctx = new VelocityContext();
		
		ctx.put("package","com.wj.suzaku");
		ctx.put("date",new DateTool());
		ctx.put("display",new DisplayTool());
		ctx.put("esc",new EscapeTool());
		ctx.put("upUnder",CaseFormat.UPPER_UNDERSCORE);
		ctx.put("upCamel",CaseFormat.UPPER_CAMEL);
		ctx.put("lowCamel",CaseFormat.LOWER_CAMEL);
		
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		Metadata metadata = new Metadata("Oracle", "192.168.1.115", "PLATFORM_V2", "PLATFORM_V2", "PLATFORM_V2");
		factoryBean.setDataSource(DataSourceFactory.createDataSource(metadata));
		MetadataService metadataService = new OracleMetadataServiceImpl(factoryBean.getObject());
		Table table = metadataService.getTable("PLATFORM_V2", "SYS_DEPT");
		ctx.put("table", table);

		StringWriter sw = new StringWriter();

		t.merge(ctx, sw);

		System.out.println(sw.toString());
		
	}

}
