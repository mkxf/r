package com.wj.suzaku;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;

import com.wj.suzaku.core.DataSourceFactory;
import com.wj.suzaku.core.SqlMapper;
import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Metadata.DbType;

public class DbPing {
	
	public static void main(String[] args){
		try {
			//Metadata metadata = new Metadata("Oracle", "192.168.1.115", "PLATFORM_V2", "PLATFORM_V2", "PLATFORM_V2");
			Metadata metadata = new Metadata("MSSQL", "127.0.0.1", "sa", "sa", "test");
			SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
			factoryBean.setDataSource(DataSourceFactory.createDataSource(metadata));
			SqlSessionFactory sqlSessionFactory = factoryBean.getObject();
			SqlSession sqlSession = sqlSessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			DbType type = DbType.valueOf(metadata.getDbType().toUpperCase());
			int rs = -1;
			if(type == DbType.MSSQL){
				rs = sqlMapper.selectOne("select 1",Integer.class);
			}else{
				rs = sqlMapper.selectOne("select 1 from dual",Integer.class);
			}
			System.out.println(rs>0);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
