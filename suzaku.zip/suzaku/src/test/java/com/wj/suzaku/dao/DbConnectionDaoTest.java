package com.wj.suzaku.dao;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.json.JSONObject;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.wj.suzaku.AppCtxSupport;
import com.wj.suzaku.model.DbConnection;

public class DbConnectionDaoTest extends AppCtxSupport{
	private static final Logger log = LoggerFactory.getLogger(DbConnectionDaoTest.class);
	
	@Autowired
	DbConnectionDao dbConnectionDao;
	String id;

	@Test
	public void testSave() {
		JSONObject json = new JSONObject("{\"name\":\"orcl_115\",\"type\":\"ORACLE\",\"host\":\"192.168.1.115\",\"username\":\"SJBANK\",\"password\":\"SJBANK\",\"schema\":\"SJBANK\"}");
		DbConnection obj = new DbConnection();
		try {
			BeanUtils.populate(obj, json.toMap());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		int rs = dbConnectionDao.save(obj);
		id = obj.getId();
		log.info("name:{} saved",obj.getName());
		log.info(JSONObject.valueToString(dbConnectionDao.getAll()));
		assertTrue(rs>0);
		
		dbConnectionDao.delete(id);
		log.info("name:{} deleted",obj.getName());
	}

	@Test
	public void testDelete() {
		JSONObject json = new JSONObject("{\"name\":\"orcl_115\",\"type\":\"ORACLE\",\"host\":\"192.168.1.115\",\"username\":\"SJBANK\",\"password\":\"SJBANK\",\"schema\":\"SJBANK\"}");
		DbConnection obj = new DbConnection();
		try {
			BeanUtils.populate(obj, json.toMap());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		int rs = dbConnectionDao.save(obj);
		id = obj.getId();
		assertTrue(rs>0);
		log.info("name:{} saved",obj.getName());
		
		rs = dbConnectionDao.delete(id);
		assertTrue(rs>0);
		log.info("name:{} deleted",obj.getName());
	}

	@Test
	public void testUpdate() {
		JSONObject json = new JSONObject("{\"name\":\"orcl_115\",\"type\":\"ORACLE\",\"host\":\"192.168.1.115\",\"username\":\"SJBANK\",\"password\":\"SJBANK\",\"schema\":\"SJBANK\"}");
		DbConnection obj = new DbConnection();
		try {
			BeanUtils.populate(obj, json.toMap());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		int rs = dbConnectionDao.save(obj);
		id = obj.getId();
		assertTrue(rs>0);
		log.info("name:{} saved",obj.getName());
		
		obj.setName("CONN_TTT$");
		rs = dbConnectionDao.update(obj);
		assertTrue(rs>0);
		
		rs = dbConnectionDao.delete(id);
		assertTrue(rs>0);
		log.info("name:{} deleted",obj.getName());
	}

	@Test
	public void testGetById() {
		JSONObject json = new JSONObject("{\"name\":\"orcl_115\",\"type\":\"ORACLE\",\"host\":\"192.168.1.115\",\"username\":\"SJBANK\",\"password\":\"SJBANK\",\"schema\":\"SJBANK\"}");
		DbConnection obj = new DbConnection();
		try {
			BeanUtils.populate(obj, json.toMap());
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		int rs = dbConnectionDao.save(obj);
		id = obj.getId();
		assertTrue(rs>0);
		log.info("name:{} saved",obj.getName());
		
		DbConnection pojo = dbConnectionDao.getById(id);
		assertTrue(pojo.getName().equals(pojo.getName()));
		
		rs = dbConnectionDao.delete(id);
		assertTrue(rs>0);
		log.info("name:{} deleted",obj.getName());
	}

	@Test
	public void testGetAll() {
		List<DbConnection> rs = dbConnectionDao.getAll();
		assertTrue(rs.size()>0);
	}

}
