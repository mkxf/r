package com.wj.suzaku.velocity;

import java.io.StringWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.apache.velocity.tools.generic.DisplayTool;
import org.apache.velocity.tools.generic.EscapeTool;
import org.mybatis.spring.SqlSessionFactoryBean;

import com.google.common.base.CaseFormat;
import com.wj.suzaku.core.DataSourceFactory;
import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.service.MetadataService;
import com.wj.suzaku.core.service.impl.OracleMetadataServiceImpl;

public class VelocityExample {

	public static void main(String[] args) throws Exception {
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());

		ve.init();

		Template t = ve.getTemplate("hellovelocity.vm");
		VelocityContext ctx = new VelocityContext();
		
		ctx.put("display",new DisplayTool());
		ctx.put("esc",new EscapeTool());
		ctx.put("upUnder",CaseFormat.UPPER_UNDERSCORE);
		ctx.put("upCamel",CaseFormat.UPPER_CAMEL);
		ctx.put("lowCamel",CaseFormat.LOWER_CAMEL);

		ctx.put("name", "velocity");
		ctx.put("date", (new Date()).toString());
		ctx.put("className", "SysUser");
		ctx.put("tableName", "t_user");
		

		List<String> list = Arrays.asList("A","B","C");
		ctx.put("list", list);
		
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		Metadata metadata = new Metadata("Oracle", "192.168.1.115", "PLATFORM_V2", "PLATFORM_V2", "PLATFORM_V2");
		factoryBean.setDataSource(DataSourceFactory.createDataSource(metadata));
		MetadataService metadataService = new OracleMetadataServiceImpl(factoryBean.getObject());
		Table table = metadataService.getTable("PLATFORM_V2", "SYS_DEPT");
		ctx.put("table", table);

		StringWriter sw = new StringWriter();

		t.merge(ctx, sw);

		System.out.println(sw.toString());
		
		System.out.println(CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, "THIS_IS_AN_EXAMPLE_STRING"));
		System.out.println(CaseFormat.UPPER_CAMEL.to(CaseFormat.UPPER_UNDERSCORE, "ThisIsAnExampleString"));
	}

}
