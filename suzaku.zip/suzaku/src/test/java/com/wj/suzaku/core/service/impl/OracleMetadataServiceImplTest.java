package com.wj.suzaku.core.service.impl;

import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wj.suzaku.core.DataSourceFactory;
import com.wj.suzaku.core.model.Column;
import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.service.MetadataService;

public class OracleMetadataServiceImplTest {
	private static final Logger logger = LoggerFactory.getLogger(OracleMetadataServiceImplTest.class);
	
	private MetadataService metadataService;
	
	@Before
	public void init() throws Exception{
		if(null==metadataService){
			SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
			Metadata metadata = new Metadata("Oracle", "192.168.1.115", "SJBANK", "SJBANK", "SJBANK");
			factoryBean.setDataSource(DataSourceFactory.createDataSource(metadata));
			metadataService = new OracleMetadataServiceImpl(factoryBean.getObject());
		}
	}

	@Test
	public void testGetSchemas() {
		Collection<String> rs = metadataService.getSchemas();
		logger.debug(JSONObject.wrap(rs).toString());
	}

	@Test
	public void testGetTables() {
		Collection<String> schemas = metadataService.getSchemas();
		String schema = (String) CollectionUtils.get(schemas, (schemas.size()-1));
		logger.debug("schema:{}",schema);
		Collection<Table> rs = metadataService.getTables(schema);
		logger.debug(JSONObject.wrap(rs).toString());
	}

	@Test
	public void testGetColumns() {
		Collection<String> schemas = metadataService.getSchemas();
		String schema = (String) CollectionUtils.get(schemas, (schemas.size()-1));
		Collection<Table> tables = metadataService.getTables(schema);
		Table table = (Table) CollectionUtils.get(tables, (tables.size()-2));
		logger.debug("schema:{},table:{}",table.getSchema(),table.getTableName());
		Collection<Column> rs = metadataService.getColumns(table.getSchema(),table.getTableName());
		logger.debug(JSONObject.wrap(rs).toString());
	}

}
