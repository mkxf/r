-- drop all TABLE
DROP TABLE IF EXISTS db_connection;

-- TABLE db_connection
CREATE TABLE db_connection (
  id int(11) NOT NULL AUTO_INCREMENT comment '连接ID',
  name VARCHAR(30) comment '连接名称',
  db_type VARCHAR(30) comment '数据库类型',
  host VARCHAR(30) comment '主机',
  username VARCHAR(30) comment '用户名',
  password VARCHAR(30) comment '密码',
  db_schema  VARCHAR(30) comment '数据库',
  PRIMARY KEY(id)
);
comment ON TABLE db_connection IS '数据库连接';
