truncate table db_connection;

-- data for TABLE db_connection

INSERT INTO db_connection (name, db_type,host, username,password,db_schema)
 VALUES ('hotel_115','ORACLE','192.168.1.115','WJ_HOTEL','WJ_HOTEL','WJ_HOTEL');

INSERT INTO db_connection (name, db_type,host, username,password,db_schema)
 VALUES ('sjbank_115','ORACLE','192.168.1.115','SJBANK','SJBANK','SJBANK');
 
INSERT INTO db_connection (name, db_type,host, username,password,db_schema)
 VALUES ('h2_127','H2','~/h2/suzaku','sa','sa','PUBLIC');
 
INSERT INTO db_connection (name, db_type,host, username,password,db_schema)
 VALUES ('citic_115','ORACLE','192.168.1.115','CITIC_MICROWEB','CITIC_MICROWEB','CITIC_MICROWEB');
 
INSERT INTO db_connection (name, db_type,host, username,password,db_schema)
 VALUES ('mssql_127','MSSQL','127.0.0.1','sa','sa','test');
 
INSERT INTO db_connection (name, db_type,host, username,password,db_schema)
 VALUES ('mysql_188','MySQL','127.0.0.1','root','sa','visa_pa');
 