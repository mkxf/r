package com.wj.web.filter;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.owasp.validator.html.AntiSamy;
import org.owasp.validator.html.CleanResults;
import org.owasp.validator.html.Policy;
import org.owasp.validator.html.PolicyException;
import org.owasp.validator.html.ScanException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XssHttpServletRequestWrapper extends HttpServletRequestWrapper {

	private static final Logger logger = LoggerFactory.getLogger(XssHttpServletRequestWrapper.class);
	private static Policy policy = null;

	public XssHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);
	}

	/**
	 * Override the original getParameterValues() method , so that it can filter
	 * all the parameter name and parameter value then use replace the special
	 * character that may cause XSS attack
	 */
	@Override
	public String[] getParameterValues(String parameter) {
		String[] values = super.getParameterValues(parameter);
		if (values == null) {
			return null;
		}
		int count = values.length;
		String[] encodedValues = new String[count];
		for (int i = 0; i < count; i++) {
			encodedValues[i] = encodeXSS(values[i]);
		}
		return encodedValues;
	}

	/**
	 * Override the original getParameter() method , so that it can filter all
	 * the parameter name and parameter value then use replace the special
	 * character that may cause XSS attack
	 */
	@Override
	public String getParameter(String name) {
		String value = super.getParameter(name);
		return encodeXSS(value);
	}

	/**
	 * Override the original getHeader() method , so that it can filter all the
	 * parameter name and parameter value then use replace the special character
	 * that may cause XSS attack
	 */
	@Override
	public String getHeader(String name) {

		String value = super.getHeader(encodeXSS(name));
		if (value != null) {
			value = encodeXSS(value);
		}
		return value;
	}

	/**
	 * Override the original getParameterMap() method , so that it can filter all the
	 * parameter name and parameter value then use replace the special character
	 * that may cause XSS attack
	 */
	@Override
	@SuppressWarnings({ "rawtypes" })
	public Map<String, String[]> getParameterMap() {
		Map<String, String[]> request_map = super.getParameterMap();
		Iterator iterator = request_map.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry me = (Map.Entry) iterator.next();
			String[] values = (String[]) me.getValue();
			for (int i = 0; i < values.length; i++) {
				values[i] = encodeXSS(values[i]);
			}
		}
		return request_map;
	}
	
	/**
	 * Override the original getInputStream() method , so that it can filter all the
	 * parameter name and parameter value then use replace the special character
	 * that may cause XSS attack
	 */
	@Override
	public ServletInputStream getInputStream() throws IOException {
		String streamValue = IOUtils.toString(super.getReader());
		if(StringUtils.isNotBlank(streamValue)){
			ResettableServletInputStream servletInputStream = new ResettableServletInputStream();
			JSONObject oldJsonObject = new JSONObject(streamValue);
	        JSONObject newJsonObject = new JSONObject();
	        for(String key : oldJsonObject.keySet())
	        {
	        	String value = oldJsonObject.get(key).toString();
	            newJsonObject.put(key, encodeXSS(value));
	        }
			servletInputStream.stream = new ByteArrayInputStream(newJsonObject.toString().getBytes());
			return servletInputStream;
		}
		return super.getInputStream();
	}

	/**
	 * replace all the characters that may cause XSS attack from half-width
	 * character to full-width character
	 * 
	 * @param s
	 * @return
	 */
	private String encodeXSS(String value) {
		if (StringUtils.isNotEmpty(value)) {
			AntiSamy antiSamy = new AntiSamy();
			try {
				final CleanResults cr = antiSamy.scan(value, getPolicy());
				// 安全的HTML输出
				value = cr.getCleanHTML();
			} catch (ScanException e) {
				logger.error("过滤XSS异常");
				// e.printStackTrace();
			} catch (PolicyException e) {
				logger.error("加载XSS规则文件异常: " + e.getMessage());
				// e.printStackTrace();
			}
		}
		return value;
	}

	private Policy getPolicy() throws PolicyException {
		if (policy == null) {
			URL url = this.getClass().getClassLoader().getResource("antisamy-default.xml");
			policy = Policy.getInstance(url.getFile());
		}
		return policy;
	}

	private class ResettableServletInputStream extends ServletInputStream {
		private InputStream stream;
		@Override
		public int read() throws IOException {
			return stream.read();
		}
		@Override
		public boolean isFinished() {
			return false;
		}
		@Override
		public boolean isReady() {
			return false;
		}
		@Override
		public void setReadListener(ReadListener readListener) {
		}
	}

}
