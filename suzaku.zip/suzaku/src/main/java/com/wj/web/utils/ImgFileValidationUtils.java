package com.wj.web.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import org.apache.commons.io.FilenameUtils;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.ContentHandler;


/**
 * 
 * 文件校验工具类
 * [包含从数据库获取系统允许上传文件的MimeType（定时刷新）、以及一些验证文件上传类型是否为可上传类型、错误提示等方法。]
 *
 */
@Component
public class ImgFileValidationUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(ImgFileValidationUtils.class);

	/**
	 * 获取允许上传的文件类型
	 * @return
	 */
	public static String[] allowedExtensions = new String[]{"jpg","gif"	,"png","bmp"};
	
	/**
	 * 获取允许上传文件类型MimeType
	 * @return
	 */
	public static String[] allowedMimeTypes  = new String[]{"image/gif","image/jpeg","image/pjpeg","image/png","image/bmp","image/x-windows-bmp"};
	
	
	//Constructor
	public ImgFileValidationUtils() {
		super();
	}
	
	/**
	 * 验证文件是否为允许上传类型
	 * @param multipartFile: org.springframework.web.multipart.MultipartFile
	 * @return
	 */
	public static boolean isAcceptType(MultipartFile multipartFile) {
		try {
			Metadata metadata = new Metadata();
			metadata.set(Metadata.RESOURCE_NAME_KEY,multipartFile.getOriginalFilename());
			Parser parser = new AutoDetectParser();
			ParseContext context = new ParseContext();
			ContentHandler contenthandler = new BodyContentHandler();
			InputStream is = new ByteArrayInputStream(multipartFile.getBytes());//ByteArrayInputStream's close is empty
			parser.parse(is, contenthandler, metadata,context);
			String mimetype = metadata.get(Metadata.CONTENT_TYPE);
			logger.debug("the validating file's mimetype is : " + mimetype);
			return Arrays.asList(allowedExtensions).contains(
					FilenameUtils.getExtension(multipartFile.getOriginalFilename()))//校验文件后缀名
					&& Arrays.asList(allowedMimeTypes).contains(mimetype);//校验文件MimeType
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return false;
	}
	/**
	 * 验证文件是否为允许上传类型
	 * @param file : java.io.File
	 * @return
	 */
	public boolean isAcceptType(File file) {
		FileInputStream is = null;
		try {
			if (file != null) {
				is = new FileInputStream(file);
				Metadata metadata = new Metadata();
				metadata.set(Metadata.RESOURCE_NAME_KEY,file.getName());
				Parser parser = new AutoDetectParser();
				ParseContext context = new ParseContext();
				ContentHandler contenthandler = new BodyContentHandler();
				parser.parse(is, contenthandler, metadata,context);
				String mimetype = metadata.get(Metadata.CONTENT_TYPE);
				logger.debug("the validating file's mimetype is : "+mimetype);
				return Arrays.asList(allowedMimeTypes).contains(mimetype) //校验MimeType
						 && Arrays.asList(allowedExtensions).contains(FilenameUtils.getExtension(file.getName()));//校验文件后缀名
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(null != is){
				try {
					is.close();
				} catch (IOException e) {
					logger.warn("IOException trying to close InputStream",e);
				}
			}
		}
		return false;
		
	}
	
    public static String getAcceptTypeErrorMsg(){
        String errorMsg = "文件上传失败，只允许上传";
        String tmp = "";
        for (int i = 0; i < allowedExtensions.length; i++) {
                tmp += allowedExtensions[i] + "、";
        }
        errorMsg += tmp.substring(0, tmp.lastIndexOf("、")) + "格式的文件";
        return errorMsg;
    }

}
