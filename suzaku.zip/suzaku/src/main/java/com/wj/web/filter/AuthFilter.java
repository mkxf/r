package com.wj.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wj.web.utils.WebUtils;

public class AuthFilter implements Filter {
	private static final Logger logger = LoggerFactory.getLogger(AuthFilter.class);
	
	/**  
      * 需要拦截的路径  
     */    
    private String includedPaths;    
	        
    private String[] includedPathArray;
	
	FilterConfig filterConfig = null;

	/** 
     * 自定义过滤规则 
     */  
	public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
        includedPaths = filterConfig.getInitParameter("includedPaths");    
        if (StringUtils.isNotEmpty(includedPaths)) {  
        	includedPathArray = includedPaths.replaceAll("[\\s]", "").split(",");  
        }else{
        	includedPathArray = new String[]{};
        }  
    }

    public void destroy() {
        this.filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException {
    	 boolean isIcludedPage = false;  
         
         HttpServletRequest req = (HttpServletRequest) request;  
         HttpServletResponse res = (HttpServletResponse) response;  
         String ctx_path = req.getContextPath();  
         String request_uri = req.getRequestURI();  
         String action = request_uri.substring(ctx_path.length());
         //判断是否需要过滤   
         for (String includePath : includedPathArray) {  
             if (action.equals(includePath) ||
            		 (includePath.startsWith("*")&& action.endsWith(includePath)) ||
            		 (includePath.endsWith("*")&& action.startsWith(includePath.substring(0, includePath.length()-1))) ) {  
                 isIcludedPage = true;   
                 break;  
             }
         }  
         
         if (isIcludedPage) {
        	 if(WebUtils.getLoginAccount(req) == null){
        		 logger.debug("request {} need login",action);
        		 String queryString = req.getQueryString();
        		 String referer = action+(StringUtils.isBlank(queryString)?"":"?"+queryString);
        		 WebUtils.setLoginReferer(req,referer);//设置登录来源
        		 res.sendRedirect(ctx_path+"/login.html");
        		 return;
        	 }
         }
         chain.doFilter(request, response);
    }

}
