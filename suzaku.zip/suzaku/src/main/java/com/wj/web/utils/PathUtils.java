package com.wj.web.utils;

import java.net.URISyntaxException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PathUtils {
	
	public static final Logger logger = LoggerFactory.getLogger(PathUtils.class);
	
	/**
	 * 获取类文件根路径
	 * @return String
	 */
	public static String getClassPath(){
		String classPath = null;
		try {
			classPath = new PathUtils().getClass().getClassLoader().getResource(".").toURI().getPath();
		} catch (URISyntaxException e) {
		}
		return classPath;
	}
	
	public static void main(String[] args) {
		System.out.println(PathUtils.getClassPath());
	}

}
