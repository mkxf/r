package com.wj.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XssFilter implements Filter {
	private static final Logger logger = LoggerFactory.getLogger(XssFilter.class);
	
	/**  
      * 需要排除的路径  
     */    
    private String excludedPaths;    
	        
    private String[] excludedPathArray;
	
	FilterConfig filterConfig = null;

	/** 
     * 自定义过滤规则 
     */  
	public void init(FilterConfig filterConfig) throws ServletException {
        this.filterConfig = filterConfig;
        excludedPaths = filterConfig.getInitParameter("excludedPaths");    
        if (StringUtils.isNotEmpty(excludedPaths)) {  
        	excludedPathArray = excludedPaths.replaceAll("[\\s]", "").split(",");  
        }else{
        	excludedPathArray = new String[]{};
        }  
    }

    public void destroy() {
        this.filterConfig = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException {
    	 boolean isExcludedPage = false;  
         
         HttpServletRequest req = (HttpServletRequest) request;  
         String ctx_path = req.getContextPath();  
         String request_uri = req.getRequestURI();  
         String action = request_uri.substring(ctx_path.length());
         
           
         //判断是否在过滤url之外   
         for (String excludePath : excludedPathArray) {  
             if (action.equals(excludePath) ||
            		 (excludePath.startsWith("*")&& action.endsWith(excludePath)) ||
            		 (excludePath.endsWith("*")&& action.startsWith(excludePath.substring(0, excludePath.length()-1))) ) {  
                 isExcludedPage = true;   
                 break;  
             }  
         }  
           
         if (isExcludedPage) {  
             chain.doFilter(request, response);  
         }else { 
        	 logger.debug("current filter request:{}",action);
        	 chain.doFilter(new XssHttpServletRequestWrapper((HttpServletRequest) request), response);
         }
    }

}
