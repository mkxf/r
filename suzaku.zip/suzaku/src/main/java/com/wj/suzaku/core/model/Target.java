package com.wj.suzaku.core.model;

import java.util.Collection;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wj.suzaku.model.DbConnection;

public class Target {
	String basePkg;
	String modules;
	String template;
	DbConnection connection;
	Collection<Table> tables;
	
	public Target() {
		super();
	}
	
	public String getBasePkg() {
		return basePkg;
	}
	public void setBasePkg(String basePkg) {
		this.basePkg = basePkg;
	}
	@JsonIgnore
	public DbConnection getConnection() {
		return connection;
	}
	public void setConnection(DbConnection connection) {
		this.connection = connection;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getModules() {
		return modules;
	}
	public void setModules(String modules) {
		this.modules = modules;
	}
	public Collection<Table> getTables() {
		return tables;
	}
	public void setTables(Collection<Table> tables) {
		this.tables = tables;
	}
	
}
