package com.wj.suzaku.core.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wj.suzaku.core.SqlMapper;
import com.wj.suzaku.core.model.Column;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.service.MetadataService;

public class OracleMetadataServiceImpl implements MetadataService {
	
	private static final Logger logger = LoggerFactory.getLogger(OracleMetadataServiceImpl.class);
	private SqlSessionFactory sessionFactory;
	
	public OracleMetadataServiceImpl(SqlSessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Collection<String> getSchemas() {
		List<String> schemas = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			String statement = "select username AS SCHEMA_NAME from dba_users where account_status='OPEN' and initial_rsrc_consumer_group='DEFAULT_CONSUMER_GROUP'";
			List<Map<String,Object>> rs = sqlMapper.selectList(statement);
			if(CollectionUtils.isEmpty(rs)){
				return schemas;
			}
			schemas = new ArrayList<String>();
			for (Map<String, Object> map : rs) {
				schemas.add(MapUtils.getString(map, "SCHEMA_NAME"));
			}
		} catch (Exception e) {
			logger.warn("获取数据库[schema]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return schemas;
	}

	@Override
	public Collection<Table> getTables(String schema) {
		List<Table> tables = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			String statement = "SELECT t.OWNER as schema, T.TABLE_NAME as tableName, T.COMMENTS as tableDesc FROM ALL_TAB_COMMENTS T WHERE T.TABLE_TYPE = 'TABLE' AND T.OWNER =  #{schema}";
			tables = sqlMapper.selectList(statement,new Table(schema),Table.class);
		} catch (Exception e) {
			logger.warn("获取数据库[table]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return tables;
	}

	@Override
	public Collection<Column> getColumns(String schema, String table) {
		List<Column> columns = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			StringBuffer statement = new StringBuffer();
			statement.append("SELECT ");
	        statement.append(" T.COLUMN_NAME as columnName, ");
	        statement.append(" T.DATA_TYPE as columnType, ");
	        statement.append(" (CASE T.NULLABLE WHEN 'Y' THEN 'true' ELSE 'false' END) as isNullable, ");
	        statement.append(" T.CHAR_COL_DECL_LENGTH as length, ");
	        statement.append(" (CASE P.CONSTRAINT_TYPE WHEN 'P' THEN 'true' ELSE 'false' END) as isPrimaryKey, ");
	        statement.append(" C.COMMENTS as columnDesc ");
	        statement.append("FROM ALL_TAB_COLUMNS T ");
	        statement.append(" LEFT JOIN ALL_COL_COMMENTS C ON T.OWNER=C.OWNER AND T.TABLE_NAME=C.TABLE_NAME AND T.COLUMN_NAME=C.COLUMN_NAME ");
	        statement.append(" LEFT JOIN ALL_CONSTRAINTS P ON P.OWNER=T.OWNER AND P.TABLE_NAME=T.TABLE_NAME AND P.CONSTRAINT_TYPE='P' ");
	        statement.append(" AND EXISTS(SELECT 1 FROM USER_CONS_COLUMNS UC WHERE UC.OWNER=P.OWNER AND UC.TABLE_NAME=P.TABLE_NAME AND ");
	        statement.append("   UC.CONSTRAINT_NAME=P.CONSTRAINT_NAME AND UC.COLUMN_NAME=T.COLUMN_NAME) ");
	        statement.append("  WHERE T.OWNER = #{schema} AND T.TABLE_NAME=#{tableName} ");
	        statement.append(" ORDER BY T.COLUMN_ID ASC ");
			
			columns = sqlMapper.selectList(statement.toString(),new Table(schema,table),Column.class);
		} catch (Exception e) {
			logger.warn("获取数据库[column]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return columns;
	}
	
	@Override
	public Table getTable(String schema, String table) {
		Table tab = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			String statement = "SELECT t.OWNER as schema, T.TABLE_NAME as tableName, T.COMMENTS as tableDesc FROM ALL_TAB_COMMENTS T "
					+ "WHERE T.TABLE_TYPE = 'TABLE' AND T.OWNER =  #{schema} AND T.TABLE_NAME=#{tableName}";
			tab = sqlMapper.selectOne(statement,new Table(schema,table),Table.class);
			if(null==tab){ return tab; }
			tab.setColumns(getColumns(schema, table));
		} catch (Exception e) {
			logger.warn("获取数据库[table]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return tab;
	}

}
