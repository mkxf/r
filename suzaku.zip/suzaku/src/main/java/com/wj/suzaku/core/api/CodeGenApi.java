package com.wj.suzaku.core.api;

import java.util.Map;

import com.wj.suzaku.core.model.Target;

public interface CodeGenApi {
	
	/**
	 * 生成代码
	 * @param target
	 * @return Map<String,Object>:{success:true|false,msg:"xxx"}
	 */
	Map<String,Object> generate(Target target);

}
