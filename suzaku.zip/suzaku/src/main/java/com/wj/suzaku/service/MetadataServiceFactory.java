package com.wj.suzaku.service;

import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.wj.suzaku.core.DataSourceFactory;
import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Metadata.DbType;
import com.wj.suzaku.core.service.MetadataService;
import com.wj.suzaku.core.service.impl.H2MetadataServiceImpl;
import com.wj.suzaku.core.service.impl.MsSqlMetadataServiceImpl;
import com.wj.suzaku.core.service.impl.MySqlMetadataServiceImpl;
import com.wj.suzaku.core.service.impl.OracleMetadataServiceImpl;
import com.wj.suzaku.model.DbConnection;

public class MetadataServiceFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(MetadataServiceFactory.class);
	
	public static MetadataService create(DbConnection connection){
		Assert.notNull(connection,"连接不能为空");
		Assert.isTrue(StringUtils.isNotBlank(connection.getType()),"数据库类型不能为空");
		
		Metadata metadata = new Metadata(connection);
		SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
		factoryBean.setDataSource(DataSourceFactory.createDataSource(metadata));
		SqlSessionFactory sqlSessionFactory = null;
		try {
			sqlSessionFactory = factoryBean.getObject();
		} catch (Exception e) {
			logger.warn("init sqlSessionFactory fail:{}", e.getMessage(),e);
		}
		
		switch (DbType.valueOf(connection.getType().toUpperCase())) {
		case ORACLE:
			return new OracleMetadataServiceImpl(sqlSessionFactory);
		case MSSQL:
			return new MsSqlMetadataServiceImpl(sqlSessionFactory);
		case MYSQL:
			return new MySqlMetadataServiceImpl(sqlSessionFactory);
		case H2:
			return new H2MetadataServiceImpl(sqlSessionFactory);
		default:
			return null;
		}
	}

}
