package com.wj.suzaku.core.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.CaseFormat;
import com.wj.suzaku.core.api.ClassApi;

public class Table implements Serializable,ClassApi{
	private static final long serialVersionUID = -8542754747868890660L;
	
	String schema;
	String tableName;
	String tableDesc;
	Collection<Column> columns = new HashSet<Column>();
	
	public Table() {
		super();
	}

	public Table(String schema) {
		this.schema = schema;
	}
	
	public Table(String schema, String tableName) {
		this.schema = schema;
		this.tableName = tableName;
	}

	public Table(String schema,String tableName, String tableDesc) {
		this.schema = schema;
		this.tableName = tableName;
		this.tableDesc = tableDesc;
	}


	public String getSchema() {
		return schema;
	}
	public void setSchema(String schema) {
		this.schema = schema;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getTableDesc() {
		if(StringUtils.isEmpty(tableDesc)){
			return getClazz();
		}
		return tableDesc;
	}
	public void setTableDesc(String tableDesc) {
		this.tableDesc = tableDesc;
	}
	public Collection<Column> getColumns() {
		return columns;
	}
	public void setColumns(Collection<Column> columns) {
		this.columns = columns;
	}

	@JsonIgnore
	@Override
	public String getLowName() {
		return this.tableName.toLowerCase();
	}
	@JsonIgnore
	@Override
	public String getClazz() {
		return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.tableName);
	}

	@JsonIgnore
	@Override
	public String getLowClazz() {
		return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, this.tableName);
	}

	@JsonIgnore
	@Override
	public Column getPkColumn() {
		Iterator<Column> it = this.columns.iterator();
		while(it.hasNext()){
			Column col = it.next();
			if(Boolean.valueOf(col.isPrimaryKey)){
				return col;
			}
		}
		return null;
	}

	@JsonIgnore
	@Override
	public String getPkId() {
		if(null == getPkColumn()){
			return null;
		}
		return getPkColumn().getColumnName();
	}

	@JsonIgnore
	@Override
	public String getId() {
		if(null == getPkColumn()){
			return null;
		}
		return getPkColumn().getField();
	}

	@JsonIgnore
	@Override
	public Set<String> getImports() {
		Set<String> imports = new HashSet<String>();
		Set<String> types = new HashSet<String>();
		Iterator<Column> it = this.columns.iterator();
		while(it.hasNext()){
			Column col = it.next();
			if(!types.contains(col.getType())){
				types.add(col.getType());
			}
		}
		
		for (String tp : types) {
			switch (tp) {
			case "Date":
				imports.add("import java.util.Date;");
				break;
			case "BigDecimal":
				imports.add("java.math.BigDecimal;");
				break;
			case "Timestamp":
				imports.add("import java.sql.Timestamp;");
				break;
			default:
				break;
			}
			
		}
		return imports;
	}
	

}
