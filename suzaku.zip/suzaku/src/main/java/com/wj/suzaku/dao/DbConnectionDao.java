package com.wj.suzaku.dao;

import java.util.List;

import com.wj.suzaku.model.DbConnection;

public interface DbConnectionDao{
	/**
	 * 保存DbConnection
	 * @param dbConnection
	 * @return
	 */
	int save(DbConnection dbConnection);
	/**
	 * 删除DbConnection
	 * @param id
	 * @return
	 */
	int delete(String id);
	/**
	 * 更新DbConnection
	 * @param dbConnection
	 * @return
	 */
	int update(DbConnection dbConnection);
	/**
	 * 根据ID获取DbConnection
	 * @param id
	 * @return
	 */
	DbConnection getById(String id);
	/**
	 * 获取所有DbConnection
	 * @return
	 */
	List<DbConnection> getAll();
	/**
	 * 查询DbConnection
	 * @param dbConnection
	 * @return
	 */
	List<DbConnection> query(DbConnection dbConnection);
}
