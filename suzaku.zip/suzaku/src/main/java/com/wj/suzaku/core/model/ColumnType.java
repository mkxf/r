package com.wj.suzaku.core.model;

import org.apache.commons.lang.math.RandomUtils;
import org.apache.ibatis.type.JdbcType;

public enum ColumnType {
	/***整数型***/
	SMALLINT,MEDIUMINT,INT,INTEGER,BIGINT,NUMBER,
	/***浮点型***/
	DECIMAL,FLOAT,DOUBLE,
	/***日期型***/
	DATE,DATETIME,TIMESTAMP,
	/***字符串型***/
	CHAR,VARCHAR,NVARCHAR,VARCHAR2,NVARCHAR2,TEXT,
	/***二进制类型***/
	BINARY,VARBINARY,BLOB,CLOB,NCLOB;

	/**
	 * 获取类型名
	 * @return
	 */
	public String getName(){
		switch (this) {
		case SMALLINT:
		case MEDIUMINT:
		case INT:
			return "int";
		case INTEGER:
		case NUMBER:
			return "Integer";
		case BIGINT:
			return "Long";
		case DECIMAL:
		case FLOAT:
		case DOUBLE:
			return "BigDecimal";
		case DATE:
		case DATETIME:
			return "Date";
		case TIMESTAMP:
			return "Timestamp";
		case CHAR:
		case VARCHAR:
		case NVARCHAR:
		case VARCHAR2:
		case NVARCHAR2:
		case TEXT:
			return "String";
		case BINARY:
		case VARBINARY:
		case BLOB:
		case CLOB:
		case NCLOB:
			return "byte[]";
		default:
			return "String";
		}
	}
	
	public static String getDefaultVal(String type,boolean isPrimaryKey){
		switch (type) {
		case "int":
		case "Integer":
			return RandomUtils.nextInt(100)+"";
		case "Long":
			return Long.valueOf(RandomUtils.nextInt(10000))+"L";
		case "String":
			if(isPrimaryKey){
				return "UUID.randomUUID().toString().replaceAll(\"[-]\", \"\")";
			}
			return "\"example"+RandomUtils.nextInt(1000)+"\"";
		case "BigDecimal":
			return "new BigDecimal(\"3.14\")";

		default:
			return "new "+type+"()";
		}
	}

	public String getJdbcType() {
		switch (this) {
		case SMALLINT:
		case MEDIUMINT:
		case INT:
			return JdbcType.INTEGER.toString();
		case INTEGER:
		case NUMBER:
			return JdbcType.INTEGER.toString();
		case BIGINT:
			return JdbcType.BIGINT.toString();
		case DECIMAL:
		case FLOAT:
		case DOUBLE:
			return JdbcType.DECIMAL.toString();
		case DATE:
		case DATETIME:
		case TIMESTAMP:
			return JdbcType.TIMESTAMP.toString();
		case CHAR:
		case VARCHAR:
		case NVARCHAR:
		case VARCHAR2:
		case NVARCHAR2:
		case TEXT:
			return JdbcType.VARCHAR.toString();
		case BINARY:
		case VARBINARY:
		case BLOB:
		case CLOB:
		case NCLOB:
			return JdbcType.BINARY.toString();
		default:
			return JdbcType.VARCHAR.toString();
		}
	}
}
