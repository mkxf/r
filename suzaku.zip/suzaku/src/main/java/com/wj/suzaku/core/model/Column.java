package com.wj.suzaku.core.model;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.base.CaseFormat;
import com.wj.suzaku.core.api.FieldApi;

public class Column implements Serializable, FieldApi {
	private static final long serialVersionUID = -1697782567776270665L;

	String columnName;
	String columnType;
	String isNullable;
	String length;
	String isPrimaryKey;
	String columnDesc;
	String isSearch;
	String isShow;
	
	public Column() {
	}

	
	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getColumnType() {
		return columnType;
	}

	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	public String getIsNullable() {
		return isNullable.toLowerCase();
	}

	public void setIsNullable(String isNullable) {
		this.isNullable = isNullable;
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public String getIsPrimaryKey() {
		return isPrimaryKey.toLowerCase();
	}

	public void setIsPrimaryKey(String isPrimaryKey) {
		this.isPrimaryKey = isPrimaryKey;
	}

	public String getColumnDesc() {
		if(StringUtils.isEmpty(columnDesc)){
			return getField();
		}
		return columnDesc;
	}

	public void setColumnDesc(String columnDesc) {
		this.columnDesc = columnDesc;
	}

	public String getIsSearch() {
		if(StringUtils.isBlank(isSearch)){
			return String.valueOf(!isPrimaryKey.equals("true"));
		}
		return isSearch;
	}

	public void setIsSearch(String isSearch) {
		this.isSearch = isSearch;
	}

	public String getIsShow() {
		if(StringUtils.isBlank(isShow)){
			return String.valueOf(!isPrimaryKey.equals("true"));
		}
		return isShow;
	}

	public void setIsShow(String isShow) {
		this.isShow = isShow;
	}

	@JsonIgnore
	@Override
	public String getField() {
		return CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, this.columnName);
	}

	@JsonIgnore
	@Override
	public String getMethodGet() {
		return String.format("get%s", CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.columnName));
	}

	@JsonIgnore
	@Override
	public String getMethodSet() {
		return String.format("set%s", CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, this.columnName));
	}

	@JsonIgnore
	@Override
	public String getType() {
		return ColumnType.valueOf(columnType.replaceAll("(\\w+)\\(.+\\)", "$1").toUpperCase()).getName();
	}
	
	@JsonIgnore
	@Override
	public String getDefaultVal() {
		return ColumnType.getDefaultVal(getType(),Boolean.valueOf(isPrimaryKey));
	}

	@JsonIgnore
	@Override
	public String getJdbcType() {
		return ColumnType.valueOf(columnType.replaceAll("(\\w+)\\(.+\\)", "$1").toUpperCase()).getJdbcType();
	}

}
