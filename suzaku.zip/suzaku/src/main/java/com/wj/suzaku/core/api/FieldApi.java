package com.wj.suzaku.core.api;

public interface FieldApi {
	/**
	 * 获取字段名称
	 * @return String
	 */
	String getField();
	/**
	 * 获取字段类型名称
	 * @return
	 */
	String getType();
	/**
	 * 获取get方法名
	 * @return String
	 */
	String getMethodGet();
	/**
	 * 获取set方法名
	 * @return String
	 */
	String getMethodSet();
	/**
	 * 获取默认值
	 * @return
	 */
	String getDefaultVal();
	/**
	 * 获取JDBC类型
	 * @return String
	 */
	String getJdbcType();

}
