package com.wj.suzaku.core.api;

import java.util.Set;

import com.wj.suzaku.core.model.Column;

public interface ClassApi {
	/**
	 * 获取类名
	 * @return String
	 */
	String getClazz();
	/**
	 * 获取首字母小写类名
	 * @return String
	 */
	String getLowClazz();
	/**
	 * 获取唯一(主键)列
	 * @return
	 */
	Column getPkColumn();
	/**
	 * 获取类唯一ID属性名
	 * (数据库唯一主键对应类属性名)
	 * @return String
	 */
	String getId();
	/**
	 * 获取主键名
	 * (数据库唯一主键名)
	 * @return String
	 */
	String getPkId();
	/**
	 * 获取类所有属性字段类型import集合
	 * @return Set<String>
	 */
	Set<String> getImports();
	/**
	 * 获取小写表名
	 * @return String
	 */
	String getLowName();
}
