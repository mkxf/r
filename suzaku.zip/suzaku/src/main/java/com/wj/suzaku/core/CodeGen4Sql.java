package com.wj.suzaku.core;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellAddress;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

public class CodeGen4Sql {
	
	private static final Logger logger = LoggerFactory.getLogger(CodeGen4Sql.class);

	public static JSONObject getJsonData(String filename) {
		JSONObject jsonRs = new JSONObject();
		try {
			Workbook workBook = null;
			InputStream ins = new FileInputStream(filename);
			workBook = WorkbookFactory.create(ins);
			Sheet sheet = workBook.getSheetAt(0);
			jsonRs.put("name", sheet.getSheetName());
			int rows = sheet.getPhysicalNumberOfRows();
			int columns = sheet.getRow(0).getPhysicalNumberOfCells();
			jsonRs.put("rows", rows);
			jsonRs.put("columns", columns);
			JSONArray datas = new JSONArray();
			for (Iterator<Row> rowIter = sheet.iterator(); rowIter.hasNext();) {
				Row row = (Row) rowIter.next();
				JSONObject data = new JSONObject();
				for(Iterator<Cell> cellIter = row.cellIterator();cellIter.hasNext();){
					Cell cell = cellIter.next();
					data.put(cell.getAddress().formatAsString().replaceAll("([A-Z]+)(\\d+)", "$1"), JSONObject.valueToString(cell));
				}
				datas.put(data);
			}
			jsonRs.put("datas", datas);
			workBook.close();
			ins.close();
			logger.debug(jsonRs.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (EncryptedDocumentException e) {
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		}
		return jsonRs;
	}
	
	public static String[] getHeadKeys(JSONObject jsonData){
		int columns = jsonData.getInt("columns");
		String[] headerKeys = new String[columns];
		for (int col = 0; col < columns; col++) {
			CellAddress addr = new CellAddress(0, col);
			String key = addr.formatAsString().replaceAll("([A-Z]+)(\\d+)", "$1");
			headerKeys[col] = key;
		}
		return headerKeys;
	}
	
	public static String[] getTitles(JSONObject jsonData,boolean includeTitle, String[] columnNames){
		String[] headerKeys = getHeadKeys(jsonData);
		boolean valid = !ArrayUtils.isEmpty(columnNames) && (columnNames.length==headerKeys.length);
		if(valid){
			for (String colName : columnNames) {
				if(StringUtils.isBlank(colName)){
					valid = false;
					break;
				}
			}
		}
		if(valid){return columnNames;}
		if(!includeTitle){return headerKeys;}
		
		int columns = jsonData.getInt("columns");
		JSONArray datas = jsonData.getJSONArray("datas");
		String[] titles = new String[columns];
		JSONObject data = datas.getJSONObject(0);
		for (int i = 0; i < headerKeys.length; i++) {
			titles[i] = data.getString(headerKeys[i]);
		}
		return titles;
	}
	
	public static String getTemplate(JSONObject jsonData,boolean includeTitle,String table,String[] columnNames){
		String[] headerKeys = getHeadKeys(jsonData);
		String[] titles = getTitles(jsonData, includeTitle,columnNames);
		String name = jsonData.getString("name");
		if(StringUtils.isNotBlank(table)){
			name = table;
		}
		StringBuffer buffer = new StringBuffer();
		buffer.append("INSERT INTO ");
		buffer.append(name);
		buffer.append(" (");
		for (int i = 0; i < titles.length; i++) {
			buffer.append(titles[i].replaceAll("\"", ""));
			if((i+1)<titles.length){
				buffer.append(",");
			}
		}
		buffer.append(") VALUES ( ");
		for (int j = 0; j < headerKeys.length; j++) {
			buffer.append("{{").append(headerKeys[j]).append("}}");
			if((j+1)<headerKeys.length){
				buffer.append(",");
			}
		}
		buffer.append(");");
		return buffer.toString();
	}
	
	public static List<String> generate(String filename,boolean includeTitle,String table, String[] titles){
		List<String> sqls = new ArrayList<String>();;
		logger.debug(filename);
		JSONObject result = CodeGen4Sql.getJsonData(filename);
		Assert.notNull(result);
		Assert.notNull(result.getJSONArray("datas"));
		Assert.notNull(result.getString("name"));
		Assert.isTrue(result.getInt("rows")>0);
		Assert.isTrue(result.getInt("columns")>0);
		
		String tpl = CodeGen4Sql.getTemplate(result,includeTitle,table,titles);
		String[] headKeys = CodeGen4Sql.getHeadKeys(result);
		JSONArray datas = result.getJSONArray("datas");
		int index = 0;
		for(Iterator<Object> dataIte = datas.iterator();dataIte.hasNext();){
			index++;
			if(includeTitle && index==1){
				dataIte.next();
			}else{
				JSONObject data = (JSONObject) dataIte.next();
				String sql = tpl;
				for (int i = 0; i < headKeys.length; i++) {
					sql = sql.replaceAll("\\{\\{"+headKeys[i]+"\\}\\}", data.getString(headKeys[i]).replaceAll("\"", "'"));
				}
				sql+=SystemUtils.LINE_SEPARATOR;
				sqls.add(sql);
			}
		}
		return sqls;
		
	}

}
