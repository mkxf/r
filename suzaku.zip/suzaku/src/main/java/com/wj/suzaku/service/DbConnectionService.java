package com.wj.suzaku.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.wj.suzaku.model.DbConnection;

public interface DbConnectionService {
	
	/**
	 * 创建DbConnection
	 * @param dbConnection
	 * @return
	 */
	int create(DbConnection dbConnection);
	/**
	 * 删除DbConnection
	 * @param id
	 * @return
	 */
	int delete(String id);
	/**
	 * 更新DbConnection
	 * @param dbConnection
	 * @return
	 */
	int update(DbConnection dbConnection);
	/**
	 * 根据ID获取DbConnection
	 * @param id
	 * @return
	 */
	DbConnection getById(String id);
	/**
	 * 获取所有DbConnection
	 * @return
	 */
	List<DbConnection> getAll();
	/**
	 * 查询DbConnection
	 * @param dbConnection
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	PageInfo<DbConnection> query(DbConnection dbConnection,int pageNum,int pageSize);
	/**
	 * 是否已存在
	 * @param dbConnection
	 * @return
	 */
	boolean isExist(DbConnection dbConnection);
	
	/**
	 * 测试数据库连接
	 * @param dbConn
	 * @return Map<String,Object> {success:true|false,msg:"xxx"}
	 */
	Map<String,Object> dialTest4Connection(DbConnection dbConn);
}
