package com.wj.suzaku.core;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.apache.velocity.tools.generic.DateTool;
import org.apache.velocity.tools.generic.DisplayTool;
import org.apache.velocity.tools.generic.EscapeTool;
import org.apache.velocity.tools.generic.LoopTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.google.common.base.CaseFormat;
import com.wj.suzaku.core.api.CodeGenApi;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.model.Target;

@Component("codeGenApi")
public class CodeGen4Java implements CodeGenApi {
	
	private static final Logger logger = LoggerFactory.getLogger(CodeGen4Java.class);
	private static final String TPL_ROOT_PATH = "velocity/default/";

	@Override
	public Map<String, Object> generate(Target target) {
		Map<String, Object> rsMap = new HashMap<String,Object>();
		
		try {
			Assert.notNull(target,"参数有误");
			Assert.notEmpty(target.getTables(),"参数有误");
			
			VelocityEngine ve = new VelocityEngine();
			ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
			ve.setProperty(Velocity.ENCODING_DEFAULT, "UTF-8");
			ve.setProperty(Velocity.INPUT_ENCODING, "UTF-8");
			ve.setProperty(Velocity.OUTPUT_ENCODING, "UTF-8");
			ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
			ve.init();
			
			VelocityContext ctx = new VelocityContext();
			ctx.put("package",target.getBasePkg());
			ctx.put("date",new DateTool());
			ctx.put("display",new DisplayTool());
			ctx.put("esc",new EscapeTool());
			ctx.put("loop",new LoopTool());
			ctx.put("upUnder",CaseFormat.UPPER_UNDERSCORE);
			ctx.put("upCamel",CaseFormat.UPPER_CAMEL);
			ctx.put("lowCamel",CaseFormat.LOWER_CAMEL);
			ctx.put("modelTpl",TPL_ROOT_PATH + "model.vm");
			ctx.put("daoTpl",TPL_ROOT_PATH + "dao.vm");
			ctx.put("daoTestTpl",TPL_ROOT_PATH + "daoTest.vm");
			ctx.put("mapperTpl",TPL_ROOT_PATH + "mapper.vm");
			ctx.put("serviceTpl",TPL_ROOT_PATH + "service.vm");
			ctx.put("serviceImplTpl",TPL_ROOT_PATH + "serviceImpl.vm");
			ctx.put("controllerTpl",TPL_ROOT_PATH + "controller.vm");
			ctx.put("listTpl",TPL_ROOT_PATH + "list.vm");
			ctx.put("editTpl",TPL_ROOT_PATH + "edit.vm");
			ctx.put("targetDir",this.getClass().getClassLoader().getResource("./").getPath()+"gen/");
			
			String[] modules = StringUtils.isNotBlank(target.getModules())?target.getModules().split(","):new String[]{};
			boolean genAll = (modules.length==0);
			for (Table table:target.getTables()) {
				Assert.notEmpty(table.getColumns(),"参数有误");
				
				if(genAll || ArrayUtils.contains(modules, "model")){
					generateModel(table, ve, ctx);
				}
				if(genAll || ArrayUtils.contains(modules, "dao")){
					generateDao(table, ve, ctx);
				}
				if(genAll || ArrayUtils.contains(modules, "service")){
					generateService(table, ve, ctx);
				}
				if(genAll || ArrayUtils.contains(modules, "web")){
					generateWeb(table, ve, ctx);
				}
			}
			
			rsMap.put("success", true);
			rsMap.put("msg", "操作成功");
		} catch (IllegalArgumentException iae) {
			rsMap.put("success", false);
			rsMap.put("msg","操作失败,"+iae.getMessage());
		} catch (Exception e) {
			logger.error("[生成代码]失败:{}",e.getMessage(),e);
			rsMap.put("success", false);
			rsMap.put("msg", "操作失败,请稍候再试");
		}
		return rsMap;
	}

	/**
	 * 生成Model层代码
	 * @param table
	 * @param engine
	 * @param ctx
	 * @throws IOException
	 */
	private void generateModel(Table table,VelocityEngine engine,VelocityContext ctx) throws IOException{
		Template tpl = engine.getTemplate((String)ctx.get("modelTpl"));
		File parent = new File((String)ctx.get("targetDir")+table.getTableName()+"/");
		if(!parent.exists()){
			FileUtils.forceMkdir(parent);
		}
		File target = new File(parent, table.getClazz()+".java");
		ctx.put("table", table);
		StringWriter sw = new StringWriter();
		tpl.merge(ctx, sw);
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		logger.info("table:{}[MODEL层]生成成功",table.getTableName());
	}
	
	/**
	 * 生成Dao层代码
	 * @param table
	 * @param engine
	 * @param ctx
	 * @throws IOException
	 */
	private void generateDao(Table table,VelocityEngine engine,VelocityContext ctx) throws IOException{
		File parent = new File((String)ctx.get("targetDir")+table.getTableName()+"/");
		if(!parent.exists()){
			FileUtils.forceMkdir(parent);
		}
		ctx.put("table", table);
		
		//mapper
		Template tpl = engine.getTemplate((String)ctx.get("mapperTpl"));
		StringWriter sw = new StringWriter();
		tpl.merge(ctx, sw);
		File target = new File(parent, table.getClazz()+".xml");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		//Dao
		tpl = engine.getTemplate((String)ctx.get("daoTpl"));
		sw = new StringWriter();
		tpl.merge(ctx, sw);
		target = new File(parent, table.getClazz()+"Dao.java");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		//DaoTest
		tpl = engine.getTemplate((String)ctx.get("daoTestTpl"));
		sw = new StringWriter();
		tpl.merge(ctx, sw);
		target = new File(parent, table.getClazz()+"DaoTest.java");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		logger.info("table:{}[DAO层]生成成功",table.getTableName());
	}
	
	/**
	 * 生成Service层代码
	 * @param table
	 * @param engine
	 * @param ctx
	 * @throws IOException
	 */
	private void generateService(Table table,VelocityEngine engine,VelocityContext ctx) throws IOException{
		File parent = new File((String)ctx.get("targetDir")+table.getTableName()+"/");
		if(!parent.exists()){
			FileUtils.forceMkdir(parent);
		}
		ctx.put("table", table);
		
		//service
		Template tpl = engine.getTemplate((String)ctx.get("serviceTpl"));
		StringWriter sw = new StringWriter();
		tpl.merge(ctx, sw);
		File target = new File(parent, table.getClazz()+"Service.java");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		//serviceImpl
		tpl = engine.getTemplate((String)ctx.get("serviceImplTpl"));
		sw = new StringWriter();
		tpl.merge(ctx, sw);
		target = new File(parent, table.getClazz()+"ServiceImpl.java");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		logger.info("table:{}[SERVICE层]生成成功",table.getTableName());
	}
	
	/**
	 * 生成Web层代码
	 * @param table
	 * @param engine
	 * @param ctx
	 * @throws IOException
	 */
	private void generateWeb(Table table, VelocityEngine engine, VelocityContext ctx) throws IOException {
		File parent = new File((String)ctx.get("targetDir")+table.getTableName()+"/");
		if(!parent.exists()){
			FileUtils.forceMkdir(parent);
		}
		ctx.put("table", table);
		
		//controller
		Template tpl = engine.getTemplate((String)ctx.get("controllerTpl"));
		StringWriter sw = new StringWriter();
		tpl.merge(ctx, sw);
		File target = new File(parent, table.getClazz()+"Controller.java");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		//list
		tpl = engine.getTemplate((String)ctx.get("listTpl"));
		sw = new StringWriter();
		tpl.merge(ctx, sw);
		target = new File(parent, "list.ftl");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
		
		//edit
		tpl = engine.getTemplate((String)ctx.get("editTpl"));
		sw = new StringWriter();
		tpl.merge(ctx, sw);
		target = new File(parent, "edit.ftl");
		FileUtils.writeStringToFile(target, sw.toString(),"UTF-8");
	
		logger.info("table:{}[WEB层]生成成功",table.getTableName());
	}

}
