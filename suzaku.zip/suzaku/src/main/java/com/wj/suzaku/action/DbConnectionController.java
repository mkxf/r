package com.wj.suzaku.action;

import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.UriComponentsBuilder;

import com.github.pagehelper.PageInfo;
import com.wj.suzaku.model.DbConnection;
import com.wj.suzaku.service.DbConnectionService;

@Controller
public class DbConnectionController {
	
	private Logger log = LoggerFactory.getLogger(DbConnectionController.class);
	
	@Autowired
	private DbConnectionService dbConnectionService;
	
	/**
	 * [FTL]展示管理页面
	 * @return
	 */
	@RequestMapping(value = "/conn", method = RequestMethod.GET)
	public String showConnList(){
		return "conn/conn";
	}
	
	/**
	 * [JSON]分页查询
	 * @param dbConnection
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/connection/", method = RequestMethod.GET)
	public ResponseEntity<PageInfo<DbConnection>> queryConnections(DbConnection dbConnection,Integer pageNum,Integer pageSize) {
		log.debug("query connections");
		PageInfo<DbConnection> result = dbConnectionService.query(dbConnection,(pageNum==null?1:pageNum),(pageSize==null?10:pageSize));
		return new ResponseEntity<PageInfo<DbConnection>>(result, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/connection/", method = RequestMethod.POST)
	public ResponseEntity<Void> createConnection(@RequestBody DbConnection conn,UriComponentsBuilder ucBuilder) {
		log.debug("创建DbConnection信息,name:{}", conn.getName());
		if (dbConnectionService.isExist(conn)) {
			log.debug("name:{}的DbConnection信息已存在", conn.getName());
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}

		dbConnectionService.create(conn);

		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(ucBuilder.path("/connection/{id}")
				.buildAndExpand(conn.getId()).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	/**
	 * [JSON]删除
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/connection/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<DbConnection> deleteConnection(@PathVariable("id") String id) {
		log.debug("查找DbConnection信息并删除,Id:{}", id);

		DbConnection target = dbConnectionService.getById(id);
		if (target == null) {
			log.debug("无法删除,DbConnection信息未找到,Id:{}", id);
			return new ResponseEntity<DbConnection>(HttpStatus.NOT_FOUND);
		}

		dbConnectionService.delete(id);
		return new ResponseEntity<DbConnection>(HttpStatus.NO_CONTENT);
	}
	
	/**
	 * 更新
	 * @param id
	 * @param conn
	 * @return
	 */
	@RequestMapping(value = "/connection/{id}", method = RequestMethod.PUT)
	public ResponseEntity<DbConnection> updateConn(@PathVariable("id") String id,@RequestBody DbConnection conn) {
		log.debug("Updating DbConnection " + id);

		DbConnection current = dbConnectionService.getById(id);

		if (current == null) {
			log.debug("DbConnection信息未找到,Id:{}", id);
			return new ResponseEntity<DbConnection>(HttpStatus.NOT_FOUND);
		}

		current.setName(conn.getName());
		current.setType(conn.getType());
		current.setHost(conn.getHost());
		current.setUsername(conn.getUsername());
		current.setPassword(conn.getPassword());
		current.setSchema(conn.getSchema());

		dbConnectionService.update(current);
		return new ResponseEntity<DbConnection>(current, HttpStatus.OK);
	}
	
	/**
	 * [JSON]详细信息
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/connection/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DbConnection> getConnection(@PathVariable("id") String id) {
		log.debug("根据Id获取DbConnection信息,Id:{}", id);
		DbConnection target = dbConnectionService.getById(id);
		if (target == null) {
			log.debug("根据Id未获取到DbConnection信息,Id:{}", id);
			return new ResponseEntity<DbConnection>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<DbConnection>(target, HttpStatus.OK);
	}
	
	/**
	 * [JSON]测试数据库连接
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/connection/test", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Object>> testConnection(DbConnection conn) {
		log.debug("测试数据库连接:{}",JSONObject.wrap(conn).toString());
		Map<String, Object> target = dbConnectionService.dialTest4Connection(conn);
		return new ResponseEntity<Map<String, Object>>(target, HttpStatus.OK);
	}
	
	

}
