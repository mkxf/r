package com.wj.suzaku.core.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wj.suzaku.core.SqlMapper;
import com.wj.suzaku.core.model.Column;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.service.MetadataService;

public class MsSqlMetadataServiceImpl implements MetadataService {
	
	private static final Logger logger = LoggerFactory.getLogger(MsSqlMetadataServiceImpl.class);
	private SqlSessionFactory sessionFactory;
	
	public MsSqlMetadataServiceImpl(SqlSessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Collection<String> getSchemas() {
		List<String> schemas = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			String statement = "select name as SCHEMA_NAME from master.dbo.sysdatabases";
			List<Map<String,Object>> rs = sqlMapper.selectList(statement);
			if(CollectionUtils.isEmpty(rs)){
				return schemas;
			}
			schemas = new ArrayList<String>();
			for (Map<String, Object> map : rs) {
				schemas.add(MapUtils.getString(map, "SCHEMA_NAME"));
			}
		} catch (Exception e) {
			logger.warn("获取数据库[schema]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return schemas;
	}

	@Override
	public Collection<Table> getTables(String schema) {
		List<Table> tables = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
//			String statement = "select table_catalog as tableSchema,table_name as tableName from information_schema.tables where table_catalog=#{schema}";
			StringBuffer statement = new StringBuffer();
			statement.append("select ");
			statement.append(" ta.table_catalog as [schema], ");
			statement.append(" t.name as tableName, ");
			statement.append(" cast(p.value as varchar(100)) as tableDesc ");
			statement.append("from sys.tables t ");
			statement.append("inner join information_schema.tables ta on ta.table_name=t.name ");
			statement.append("left join sys.extended_properties p on p.major_id=t.object_id ");
			statement.append("where p.minor_id=0 and ta.table_catalog=#{schema} ");
			tables = sqlMapper.selectList(statement.toString(),new Table(schema),Table.class);
		} catch (Exception e) {
			logger.warn("获取数据库[table]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return tables;
	}

	@Override
	public Collection<Column> getColumns(String schema, String table) {
		List<Column> columns = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			StringBuffer statement = new StringBuffer();
//			statement.append("select  ");
//			statement.append("	c.column_name as columnName, ");
//			statement.append("	c.data_type as columnType,  ");
//			statement.append("	(CASE c.is_nullable WHEN 'YES' THEN 'true' ELSE 'false' END) as isNullable, ");
//			statement.append("	(CASE WHEN c.character_maximum_length IS NULL THEN c.numeric_precision ELSE c.character_maximum_length END)as length ");
//			statement.append("from information_schema.columns c ");
//			statement.append("where c.table_catalog = #{schema} ");
//			statement.append(" and c.table_name = #{tableName} ");
//			statement.append("order by c.ORDINAL_POSITION asc; ");
			
			statement.append("select ");
			statement.append("  c.name as columnName, ");
			statement.append("  co.data_type as columnType, ");
			statement.append("  (CASE WHEN co.character_maximum_length IS NULL THEN co.numeric_precision ELSE co.character_maximum_length END)as length, ");
			statement.append("  (CASE c.is_identity WHEN 1 THEN 'true' ELSE 'false'END)as isPrimaryKey, ");
			statement.append("  (CASE c.is_nullable WHEN 1 THEN 'true' ELSE 'false'END)as isNullable, ");
			statement.append("  cast(p.value as varchar(100)) as columnDesc ");
			statement.append(" from sys.columns c ");
			statement.append(" inner join sys.tables t on t.object_id = c.object_id ");
			statement.append(" inner join information_schema.columns co on co.column_name = c.name and co.table_name=t.name ");
			statement.append(" left join sys.extended_properties p on p.major_id=t.object_id and p.minor_id=c.column_id ");
			statement.append("where co.table_catalog = #{schema} and t.name = #{tableName} ");
			statement.append("order by c.column_id ASC ");
			
			logger.debug("querySql:{}",statement.toString());
			columns = sqlMapper.selectList(statement.toString(),new Table(schema,table),Column.class);
		} catch (Exception e) {
			logger.warn("获取数据库[column]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return columns;
	}

	@Override
	public Table getTable(String schema, String table) {
		Table tab = null;
		SqlSession sqlSession = null;
		try {
			sqlSession = sessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
//			String statement = "select table_catalog as tableSchema,table_name as tableName from information_schema.tables where table_catalog=#{schema} AND table_name=#{tableName}";
			StringBuffer statement = new StringBuffer();
			statement.append("select ");
			statement.append(" ta.table_catalog as [schema], ");
			statement.append(" t.name as tableName, ");
			statement.append(" cast(p.value as varchar(100)) as tableDesc ");
			statement.append("from sys.tables t ");
			statement.append("inner join information_schema.tables ta on ta.table_name=t.name ");
			statement.append("left join sys.extended_properties p on p.major_id=t.object_id ");
			statement.append("where p.minor_id=0 and ta.table_catalog=#{schema} ");
			statement.append("and t.name=#{tableName} ");
			
			tab = sqlMapper.selectOne(statement.toString(),new Table(schema,table),Table.class);
			if(null==tab){ return tab; }
			tab.setColumns(getColumns(schema, table));
		} catch (Exception e) {
			logger.warn("获取数据库[table]失败:{}", e.getMessage(),e);
		}finally {
			if(sqlSession != null){
				sqlSession.close();
			}
		}
		return tab;
	}

}
