package com.wj.suzaku.core.model;

import java.util.Set;

import org.json.JSONObject;

import com.wj.suzaku.model.DbConnection;

public class Metadata {
	
	public enum DbType{
		ORACLE,MYSQL,MSSQL,H2
	}
	/*********fields**********/
	String dbType;
	String host;
	String username;
	String password;
	String schema;
	Set<String> schemas;
	Set<Table> tables;
	
	/*********constructors**********/
	public Metadata() {
		super();
	}

	public Metadata(String dbType, String host, String username, String password, String schema) {
		super();
		this.dbType = dbType;
		this.host = host;
		this.username = username;
		this.password = password;
		this.schema = schema;
	}
	
	public Metadata(DbConnection dbConn) {
		super();
		this.dbType = dbConn.getType();
		this.host = dbConn.getHost();
		this.username = dbConn.getUsername();
		this.password = dbConn.getPassword();
		this.schema = dbConn.getSchema();
	}

	/*********getters and setters**********/
	public String getDbType() {
		return dbType;
	}

	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public Set<Table> getTables() {
		return tables;
	}

	public void setTables(Set<Table> tables) {
		this.tables = tables;
	}

	public Set<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(Set<String> schemas) {
		this.schemas = schemas;
	}

	public String getUrl(){
		String url = null;
		int port = -1;
		switch (DbType.valueOf(dbType.toUpperCase())) {
		case ORACLE:
			port = 1521;
			url = String.format("jdbc:oracle:thin:@%s:%d:orcl", host,port);
			break;
		case MYSQL:
			port = 3306;
			url = String.format("jdbc:mysql://%s:%d/%s", host,port,schema);
			break;
		case MSSQL:
			port = 1433;
			url = String.format("jdbc:sqlserver://%s:%d;DatabaseName=%s", host,port,schema);
			break;
		case H2:
			url = String.format("jdbc:h2:%s", host);
			break;
		}
		return url;
	}

	public static void main(String[] args) {
		System.out.println(JSONObject.wrap(new Metadata("Oracle", "127.0.0.1", "sa", "sa", "schema")).toString());
		System.out.println(JSONObject.wrap(new Metadata("MySQL", "127.0.0.1", "sa", "sa", "schema")).toString());
		System.out.println(JSONObject.wrap(new Metadata("MSSQL", "127.0.0.1", "sa", "sa", "schema")).toString());
		System.out.println(JSONObject.wrap(new Metadata("H2", "~/h2/suzaku", "sa", "sa", "schema")).toString());
	}
}
