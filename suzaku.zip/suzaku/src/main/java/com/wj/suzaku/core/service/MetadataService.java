package com.wj.suzaku.core.service;

import java.util.Collection;

import com.wj.suzaku.core.model.Column;
import com.wj.suzaku.core.model.Table;

public interface MetadataService {
	
	Collection<String> getSchemas();
	
	Collection<Table> getTables(String schema);
	
	Collection<Column> getColumns(String schema,String table);

	Table getTable(String schema, String table);
}
