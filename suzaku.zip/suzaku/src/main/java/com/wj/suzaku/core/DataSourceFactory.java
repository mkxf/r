package com.wj.suzaku.core;

import java.sql.Driver;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Metadata.DbType;

public class DataSourceFactory {
	
	private static final Logger logger = LoggerFactory.getLogger(DataSourceFactory.class);
	
	public static DataSource createDataSource(String url,String username,String password,DbType dbType){
		DataSource dataSource = null;
		Driver driver = null;
		try {
			switch (dbType) {
			case ORACLE:
				driver = (Driver) Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
				break;
			case MYSQL:
				driver = (Driver) Class.forName("com.mysql.jdbc.Driver").newInstance();
				break;
			case H2:
				driver = (Driver) Class.forName("org.h2.Driver").newInstance();
				break;
			case MSSQL:
				driver = (Driver) Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
				break;
			default:
				break;
			}
		} catch (Exception e) {
			logger.error("获取数据库驱动类失败：{}", e.getMessage(),e);
		}
		dataSource = new SimpleDriverDataSource(driver, url, username, password );
		return dataSource;
	}
	
	public static DataSource createDataSource(Metadata metadata){
		DataSource dataSource = null;
		if(metadata == null){
			return dataSource;
		}
		dataSource = createDataSource(metadata.getUrl(), metadata.getUsername(), metadata.getPassword(), DbType.valueOf(metadata.getDbType().toUpperCase()));
		return dataSource;
	}
	

}
