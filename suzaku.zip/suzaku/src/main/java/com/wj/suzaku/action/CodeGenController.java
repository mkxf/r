package com.wj.suzaku.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wj.suzaku.core.api.CodeGenApi;
import com.wj.suzaku.core.model.Column;
import com.wj.suzaku.core.model.Table;
import com.wj.suzaku.core.model.Target;
import com.wj.suzaku.core.service.MetadataService;
import com.wj.suzaku.model.DbConnection;
import com.wj.suzaku.service.DbConnectionService;
import com.wj.suzaku.service.MetadataServiceFactory;
import com.wj.web.utils.PathUtils;

@Controller
public class CodeGenController {

	private static final Logger logger = LoggerFactory.getLogger(CodeGenController.class);

	@Autowired
	private DbConnectionService dbConnectionService;
	@Autowired
	private CodeGenApi codeGenApi;

	/**
	 * [FTL]快速生成
	 * 
	 * @param conn
	 * @param basePkg
	 * @param tables
	 * @param response
	 * @param model
	 * @param attrs
	 * @return
	 */
	@RequestMapping(value = { "/fast" })
	public String showFastGen(DbConnection conn, String basePkg, String tables,String tpl, HttpServletResponse response,
			ModelMap model, RedirectAttributes attrs) {
		logger.debug("快速生成:{}", JSONObject.wrap(conn).toString());

		if (StringUtils.isBlank(conn.getId())) {
			return "fast/fast_step_1";
		}

		conn = dbConnectionService.getById(conn.getId());
		model.addAttribute("connection", conn);
		MetadataService metadataService = MetadataServiceFactory.create(conn);
		Collection<Table> tableRs = metadataService.getTables(conn.getSchema());
		model.addAttribute("tables", tableRs);

		if (StringUtils.isBlank(tables)) {
			return "fast/fast_step_2";
		}
		logger.debug("tables:{}", tables);

		List<Table> targets = new ArrayList<Table>();
		String[] tabArr = tables.split(",");
		for (Table table : tableRs) {
			if (ArrayUtils.contains(tabArr, table.getTableName())) {
				Collection<Column> columns = metadataService.getColumns(table.getSchema(), table.getTableName());
				table.setColumns(columns);
				targets.add(table);
			}
		}

		Target t = new Target();
		t.setConnection(conn);
		t.setTables(targets);
		t.setTemplate(tpl);
		t.setModules("web,service,model,dao");
		t.setBasePkg(basePkg);
		logger.debug("[快速生成代码]参数:{}", JSONObject.wrap(t).toString());
		Map<String, Object> result = codeGenApi.generate(t);
		attrs.addFlashAttribute("success", MapUtils.getBooleanValue(result, "success"));
		attrs.addFlashAttribute("msg", MapUtils.getString(result, "msg"));
		return "redirect:code";

	}
	
	/**
	 * [FTL]自定义生成
	 * 
	 * @param conn
	 * @param basePkg
	 * @param tables
	 * @param response
	 * @param model
	 * @param attrs
	 * @return
	 */
	@RequestMapping(value = { "/custom" })
	public String showCustomGen(DbConnection conn, String tables, String basePkg, String modules,String tpl,
			HttpServletRequest request, HttpServletResponse response, ModelMap model, RedirectAttributes attrs) {
		logger.debug("自定义生成 conn:{}", JSONObject.wrap(conn).toString());

		if (StringUtils.isBlank(conn.getId())) {
			return "custom/custom_step_1";
		}
		
		conn = dbConnectionService.getById(conn.getId());
		model.addAttribute("connection", conn);
		MetadataService metadataService = MetadataServiceFactory.create(conn);
		
		if (StringUtils.isBlank(tables)) {
			Collection<Table> tableRs = metadataService.getTables(conn.getSchema());
			model.addAttribute("tables", tableRs);
			return "custom/custom_step_2";
		}
		
		Table table = metadataService.getTable(conn.getSchema(), tables);
		if(StringUtils.isBlank(basePkg)){
			model.addAttribute("table", table);
			return "custom/custom_step_3";
		}
		
		String[] columnDesc = request.getParameterValues("columnDesc");
		String[] isNullable = request.getParameterValues("isNullable");
		String[] isSearch = request.getParameterValues("isSearch");
		String[] isShow = request.getParameterValues("isShow");
		int index = 0;
		for (Column column : table.getColumns()) {
			column.setColumnDesc(columnDesc[index]);
			column.setIsShow(isShow[index]);
			column.setIsNullable(isNullable[index]);
			column.setIsSearch(isSearch[index]);
			index++;
		}
		
		Target t = new Target();
		t.setConnection(conn);
		t.setTemplate(tpl);
		t.setTables(Arrays.asList(table));
		t.setBasePkg(basePkg);
		t.setModules(modules);
		logger.debug("[自定义生成代码]参数:{}", JSONObject.wrap(t).toString());
		Map<String, Object> result = codeGenApi.generate(t);
		attrs.addFlashAttribute("success", MapUtils.getBooleanValue(result, "success"));
		attrs.addFlashAttribute("msg", MapUtils.getString(result, "msg"));
		return "redirect:code";
	}
	
	
	/**
	 * [FTL][JSON]生成
	 * 
	 * @param jsonData
	 * @param model
	 * @param attrs
	 * @return
	 */
	@RequestMapping(value = { "/advance" })
	public String showAdvanceGen(String jsonData,ModelMap model, RedirectAttributes attrs) {
		jsonData = HtmlUtils.htmlUnescape(jsonData);
		logger.debug("[JSON]生成代码,参数:{}", jsonData);

		if (StringUtils.isBlank(jsonData)) {
			return "advance/advance_step_1";
		}
		
		ObjectMapper mapper = new ObjectMapper();
		Target t = null;
		try {
			t = mapper.readValue(jsonData, Target.class);
		} catch (IOException e) {
			attrs.addFlashAttribute("success",false);
			attrs.addFlashAttribute("msg", "JSON格式不正确");
			return "redirect:code";
		}
		
		logger.debug("[JSON]生成代码,参数:{}", JSONObject.wrap(t).toString());
		Map<String, Object> result = codeGenApi.generate(t);
		attrs.addFlashAttribute("success", MapUtils.getBooleanValue(result, "success"));
		attrs.addFlashAttribute("msg", MapUtils.getString(result, "msg"));
		return "redirect:code";

	}
	
	/**
	 * 导出JSON
	 */
	@RequestMapping(value = { "/export/json" })
	public String doExport(DbConnection conn,HttpServletRequest request,RedirectAttributes attrs){
		conn = dbConnectionService.getById(conn.getId());
		String[] tables = request.getParameterValues("tables");
		String tpl = request.getParameter("tpl");
		String basePkg = request.getParameter("basePkg");
		
		MetadataService metadataService = MetadataServiceFactory.create(conn);
		Collection<Table> tableRs = metadataService.getTables(conn.getSchema());
		
		List<Table> targets = new ArrayList<Table>();
		for (Table table : tableRs) {
			if (ArrayUtils.contains(tables, table.getTableName())) {
				Collection<Column> columns = metadataService.getColumns(table.getSchema(), table.getTableName());
				table.setColumns(columns);
				targets.add(table);
			}
		}

		Target t = new Target();
		t.setConnection(conn);
		t.setTables(targets);
		t.setTemplate(tpl);
		t.setModules("web,service,model,dao");
		t.setBasePkg(basePkg);
		
		logger.debug("[导出JSON]:{}", JSONObject.wrap(t).toString());
		
		try {
			File parent = new File(PathUtils.getClassPath()+"gen/"+basePkg+"/");
			if(!parent.exists()){
				FileUtils.forceMkdir(parent);
			}
			File target = new File(parent, basePkg+".json");
			ObjectMapper mapper = new ObjectMapper();
			String result = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(t);
			FileUtils.writeStringToFile(target, result,"UTF-8");
		} catch (IOException e) {
			logger.error("生成JSON文件失败");
		}
		
		attrs.addFlashAttribute("success", true);
		attrs.addFlashAttribute("msg", "生成JSON文件成功");
		return "redirect:/code";
	}

	/**
	 * [FTL]代码下载首页
	 * 
	 * @param model
	 * @param attrs
	 * @return
	 */
	@RequestMapping(value = { "/code" })
	public String showCodeList(ModelMap model, RedirectAttributes attrs) {
		List<String> dirs = new ArrayList<String>();
		String parentDir = String.format("%sgen", PathUtils.getClassPath());
		File[] files = FileUtils.getFile(parentDir).listFiles();
		if (!ArrayUtils.isEmpty(files)) {
			for (File file : files) {
				if(file.isDirectory()){
					dirs.add(file.getName());
				}
			}
		}
		model.addAttribute("files", dirs);
		return "code/result";
	}

	/**
	 * [FTL]代码清单
	 * 
	 * @param dir
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/browse",method = RequestMethod.GET)
	public String showCodeBrowse(String dir, ModelMap model) {
		List<String> sources = new ArrayList<String>();
		String directory = String.format("%s%s", PathUtils.getClassPath(), dir);
		File[] files = FileUtils.getFile(directory).listFiles();
		if (!ArrayUtils.isEmpty(files)) {
			for (File file : files) {
				sources.add(file.getName());
			}
		}
		model.addAttribute("dir", dir);
		model.addAttribute("files", sources);
		return "code/files";
	}

	/**
	 * [FTL]代码预览
	 * 
	 * @param dir
	 * @param filename
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/code/view")
	public String showCodePreview(String dir, String filename, ModelMap model) {
		String parentDir = PathUtils.getClassPath();
		String fileName = String.format("%s%s/%s", parentDir, dir, filename);
		File target = FileUtils.getFile(fileName);
		List<String> lines = new ArrayList<>();
		try {
			if(target.exists()){
				lines = FileUtils.readLines(target, "utf-8");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		model.addAttribute("sufix", FilenameUtils.getExtension(target.getName()));
		model.addAttribute("dir", dir);
		model.addAttribute("lines", lines);
		return "code/files_detail";
	}

	@RequestMapping("/download")
	public void codeDownload(String dir, String filename, String zip, HttpServletResponse response) {
		try {
			String fileName = null;
			String rootPath = PathUtils.getClassPath();
			if (StringUtils.isNotBlank(zip)) {
				fileName = rootPath + "gen/" + filename + ".zip";
				File[] sourceFiles = new File(rootPath + "gen/" + filename).listFiles();
				ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)));
				String baseDir = filename+"/";
				byte[] bufs = new byte[1024 * 10];
				for (int i = 0; i < sourceFiles.length; i++) {
					// 创建ZIP实体，并添加进压缩包
					ZipEntry zipEntry = new ZipEntry(baseDir+sourceFiles[i].getName());
					zos.putNextEntry(zipEntry);
					// 读取待压缩的文件并写进压缩包里
					FileInputStream fis = new FileInputStream(sourceFiles[i]);
					BufferedInputStream bis = new BufferedInputStream(fis, 1024 * 10);
					int read = 0;
					while ((read = bis.read(bufs, 0, 1024 * 10)) != -1) {
						zos.write(bufs, 0, read);
					}
					fis.close();
					bis.close();
				}
				zos.closeEntry();
				zos.close();
				filename += ".zip";
			} else {
				fileName = rootPath + dir + "/" + filename;
			}

			response.setHeader("Content-Type", "application/octet-stream");
			response.setHeader("Content-Disposition", "attachment; filename=" + filename);
			
			logger.info("下载文件[{}]",filename);

			ServletOutputStream out = response.getOutputStream();
			FileInputStream in = new FileInputStream(fileName);
			StreamUtils.copy(in, out);
			// 关闭流
			in.close();
			out.flush();
			out.close();
		} catch (IOException e) {
			logger.error("下载代码失败:{}", e.getMessage(), e);
		}

	}

}
