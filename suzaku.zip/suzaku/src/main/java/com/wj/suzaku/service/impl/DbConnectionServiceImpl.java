package com.wj.suzaku.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wj.suzaku.core.DataSourceFactory;
import com.wj.suzaku.core.SqlMapper;
import com.wj.suzaku.core.model.Metadata;
import com.wj.suzaku.core.model.Metadata.DbType;
import com.wj.suzaku.dao.DbConnectionDao;
import com.wj.suzaku.model.DbConnection;
import com.wj.suzaku.service.DbConnectionService;

@Service("dbConnectionService")
@Transactional
public class DbConnectionServiceImpl implements DbConnectionService {
	private static final Logger log = LoggerFactory.getLogger(DbConnectionServiceImpl.class);
	@Autowired
	private DbConnectionDao dbConnectionDao;
	
	public int create(DbConnection dbConnection) {
		int rs = dbConnectionDao.save(dbConnection);
		log.info("create dbConnection:{} success",dbConnection.getName());
		return rs;
	}

	public int delete(String id) {
		int rs = dbConnectionDao.delete(id);
		log.info("delete dbConnection:{} success",id);
		return rs;
	}

	public int update(DbConnection dbConnection) {
		return dbConnectionDao.update(dbConnection);
	}

	public DbConnection getById(String id) {
		return dbConnectionDao.getById(id);
	}

	public List<DbConnection> getAll() {
		return dbConnectionDao.getAll();
	}

	public PageInfo<DbConnection> query(DbConnection dbConnection,int pageNum,int pageSize) {
		PageHelper.startPage(pageNum, pageSize);
		PageHelper.orderBy("id desc");
		List<DbConnection> list = dbConnectionDao.query(dbConnection);
		PageInfo<DbConnection> info = new PageInfo<DbConnection>(list);
		return info;
	}

	public boolean isExist(DbConnection dbConnection) {
		DbConnection param = new DbConnection();
		param.setName(dbConnection.getName());
		List<DbConnection> list = dbConnectionDao.query(param);
		if(CollectionUtils.isNotEmpty(list)){
			return true;
		}
		return false;
	}

	@Override
	public Map<String, Object> dialTest4Connection(DbConnection dbConn) {
		Map<String, Object> rsMap = new HashMap<String, Object>();
		boolean success = false;
		try {
			Assert.notNull(dbConn, "参数有误");
			Assert.isTrue(StringUtils.isNotBlank(dbConn.getType()), "数据库类型不能为空");
			Assert.isTrue(StringUtils.isNotBlank(dbConn.getHost()), "主机名不能为空");
			Assert.isTrue(StringUtils.isNotBlank(dbConn.getUsername()), "用户名不能为空");
			Assert.isTrue(StringUtils.isNotBlank(dbConn.getPassword()), "密码不能为空");
			Assert.isTrue(StringUtils.isNotBlank(dbConn.getSchema()), "数据库不能为空");
			
			Metadata metadata = new Metadata(dbConn);
			SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
			factoryBean.setDataSource(DataSourceFactory.createDataSource(metadata));
			SqlSessionFactory sqlSessionFactory = factoryBean.getObject();
			SqlSession sqlSession = sqlSessionFactory.openSession();
			SqlMapper sqlMapper = new SqlMapper(sqlSession);
			int dualRs = -1;
			DbType type = DbType.valueOf(metadata.getDbType().toUpperCase());
			if(type == DbType.MSSQL){
				dualRs = sqlMapper.selectOne("select 1",Integer.class);
			}else{
				dualRs = sqlMapper.selectOne("select 1 from dual",Integer.class);
			}
			success = dualRs>0;
			rsMap.put("msg", success?"连接成功":"连接失败");
		} catch (IllegalArgumentException e) {
			rsMap.put("msg", e.getMessage());
		} catch (PersistenceException e) {
			String msg = e.getMessage();
			if(msg.indexOf("invalid username/password") != -1){
				msg = "连接失败：用户名或密码不正确";
			}
			if(msg.indexOf("The Network Adapter could not establish") != -1){
				msg = "连接失败：主机名有误或网络不通";
			}
			rsMap.put("msg", msg);
		} catch (Exception e) {
			log.error("[测试DB连接]失败:{}",e.getMessage(),e);
			rsMap.put("msg", "连接失败,请检查网络或连接参数");
		}
		rsMap.put("success", success);
		return rsMap;
	}

}
