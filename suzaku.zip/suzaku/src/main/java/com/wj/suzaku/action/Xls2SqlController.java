package com.wj.suzaku.action;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ArrayUtils;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wj.suzaku.core.CodeGen4Sql;
import com.wj.web.utils.PathUtils;

@Controller
public class Xls2SqlController {
	
	/**
	 * [FTL]xls转sql页面
	 * @return
	 */
	@RequestMapping(value = "/xls2sql", method = RequestMethod.GET)
	public String showXls2Sql(){
		return "xls/xls2sql";
	}
	
	/**
	 * [JSON]获取excel已上传文件清单
	 * @return
	 */
	@RequestMapping(value = "/xls2sql/files")
	public @ResponseBody String codeBrowse() {
		List<String> sources = new ArrayList<String>();
		String directory = String.format("%s%s", PathUtils.getClassPath(), "upload/");
		File[] files = FileUtils.getFile(directory).listFiles();
		if (!ArrayUtils.isEmpty(files)) {
			for (File file : files) {
				sources.add(file.getName());
			}
		}
		return JSONObject.wrap(sources).toString();
	}
	
	
	/**
	 * [JSON]获取excel生成sql内容
	 * @return
	 */
	@RequestMapping(value = "/xls2sql", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String doXls2Sql(String target,String hasTitle,String table,String titles){
		String filename = String.format("%supload/%s", PathUtils.getClassPath(), target);
		List<String> sqls = CodeGen4Sql.generate(filename, Boolean.valueOf(hasTitle),table,titles.split(","));
		return JSONObject.wrap(sqls).toString();
	}
}
