package com.wj.suzaku.action;

import java.io.File;

import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/upload")
public class UploadController {
	
	private final static org.slf4j.Logger logger = LoggerFactory.getLogger(UploadController.class);
	
	@RequestMapping(method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseBody
    public String handleUploadProcess(MultipartFile file)  
            throws Exception {
		logger.debug("upload invoked!");
		JSONObject rsJson = new JSONObject();
		String fileName="";
		try {
			if (!file.isEmpty()){  
				fileName = file.getOriginalFilename();
				logger.debug(fileName);
				String filePath = this.getClass().getClassLoader().getResource("./").getPath()+"upload/"+fileName;
				File dest = new File(filePath);
				if(!dest.exists()){
					dest.mkdirs();
				}
				file.transferTo(dest);
				rsJson.put("success", "true");
				rsJson.put("msg", String.format("[%s]上传成功", fileName));
			}
		} catch (Exception e) {
			logger.error("上传文件异常:"+fileName, e);
			rsJson.put("success", "false");
			rsJson.put("msg", "上传失败");
		}  
		return rsJson.toString();
    }
}
